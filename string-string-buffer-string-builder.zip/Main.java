/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main{  
    public static void main(String[] args){  
        String s="string";
        StringBuffer b1=new StringBuffer("string buffer ");  
        b1.append("execution");  
        StringBuilder b2=new StringBuilder("string builder ");  
        b2.append("execution");  
        System.out.println(s);
        System.out.println(b1); 
        System.out.println(b2); 
        
    }  
}  