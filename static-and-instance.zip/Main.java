/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    static int a=20;
    int b=15;
	public static void main(String[] args) {
	    Main m1= new Main();
	    m1.a=100;
	    m1.b=200;
	    Main m2= new Main();
		System.out.println("a="+m2.a +"b=" +m2.b);
	}
}
